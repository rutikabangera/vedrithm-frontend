import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SiteConfigService } from '../../services/site-config.service';

@Component({
  selector: 'app-whatsapp-button',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="wa-float-wrapper">
      <div class="wa-tooltip" [class.show]="showTooltip">Order on WhatsApp 🌿</div>
      <a [href]="waUrl"
         target="_blank"
         class="wa-float"
         (mouseenter)="showTooltip=true"
         (mouseleave)="showTooltip=false"
         aria-label="Chat on WhatsApp">
        <svg viewBox="0 0 24 24" fill="white" width="28">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
        </svg>
        <div class="ripple"></div>
      </a>
    </div>
  `,
  styles: [`
    .wa-float-wrapper { position: fixed; bottom: 2rem; right: 2rem; z-index: 999; display: flex; flex-direction: column; align-items: flex-end; }
    .wa-tooltip { background: var(--forest-mid); color: var(--gold); border: 1px solid var(--border-gold); padding: 0.5rem 0.9rem; border-radius: 4px; font-size: 0.78rem; font-weight: 500; white-space: nowrap; opacity: 0; transform: translateY(8px); transition: all 0.3s ease; pointer-events: none; margin-bottom: 0.6rem; }
    .wa-tooltip.show { opacity: 1; transform: translateY(0); }
    .wa-float { width: 58px; height: 58px; background: #25d366; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 6px 25px rgba(37,211,102,0.4); transition: all 0.3s ease; position: relative; overflow: visible; }
    .wa-float:hover { transform: scale(1.08); box-shadow: 0 8px 35px rgba(37,211,102,0.5); }
    .ripple { position: absolute; width: 100%; height: 100%; border-radius: 50%; background: #25d366; animation: rippleAnim 2s infinite; z-index: -1; }
    @keyframes rippleAnim { 0% { transform: scale(1); opacity: 0.4; } 100% { transform: scale(1.8); opacity: 0; } }
  `]
})
export class WhatsappButtonComponent implements OnInit {
  showTooltip = false;
  waUrl = '';

  constructor(private configService: SiteConfigService) {}

  ngOnInit() {
    this.configService.stream.subscribe(cfg => {
      const msg = `Hi! I'm interested in Vedrithm Herbal Hair Oil. Please share more details.`;
      this.waUrl = `https://wa.me/${cfg.whatsappNumber}?text=${encodeURIComponent(msg)}`;
    });
  }
}
